//
//  ContentView.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

struct SchoolsListView: View {
    
    @ObservedObject var ViewModel = SchoolsListViewModel()
    
    @State var deatilSchool:SchoolsListModel


    @State private var path = [String]()

    var body: some View {
        NavigationStack(path: $path){
            VStack {
                
                List{
                    ForEach(ViewModel.schoolsList) { schoolObject in
                        
                        SchoolListRowView(schoolList: schoolObject)
                        
                        deatilSchool = schoolObject

                        
                            .onTapGesture {
                                
                                path.append("SchoolDetails")
                                
                                
                                
                            }
                    }
                }
            }
                        .navigationDestination(for: String.self, destination: { selection in
            
                            if selection == "SchoolDetails" {
            

                            }
                           
                        })
                        .navigationBarBackButtonHidden()
        }
        .padding()
      
        .task {
           ViewModel.getSchoolsList()
        }
    }
}
