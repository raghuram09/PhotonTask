//
//  SchoolsViewModel.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import Foundation

class SchoolsListViewModel:ObservableObject{
    
    @Published var schoolsList:[SchoolsListModel] = []
    
    
    func getSchoolsList()  {
        
        ApiHandler.shared.getSchoolsList { responce in
            
            switch responce{
               
            case .success(let schoolsListRes):
                
                self.schoolsList = schoolsListRes
                
                print(self.schoolsList)
                
            case .failure(let error):
                
                print(error.localizedDescription)
                
            }
            
        }
        
    }
    
}
