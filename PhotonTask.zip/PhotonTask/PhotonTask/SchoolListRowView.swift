//
//  SchoolListRowView.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

struct SchoolListRowView: View {
    let schoolList:SchoolsListModel
    var body: some View {

        VStack(alignment: .leading){
            
            Text("Id: \(schoolList.dbn)")
                .font(.system(size: 20))
                .fontWeight(.bold)
                .lineLimit(1)
            
            Text("Id: \(schoolList.school_name)")
                .font(.system(size: 20))
                .fontWeight(.bold)
           
        }
        
    }
}

