//
//  SchoolsModel.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import Foundation


class SchoolsListModel:Codable,Identifiable{
    
    var dbn:String
    var school_name:String
    
    
}
