//
//  Extensions.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import Foundation

extension URL{
    
    static func SchoolsUrl() -> URL?{
        
        
        return URL(string: "https://data.cityofnewyork.us/resource/s3k6-pzi2.json")
    }
}
