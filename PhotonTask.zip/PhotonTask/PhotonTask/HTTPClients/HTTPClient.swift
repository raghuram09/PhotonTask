//
//  HTTPClient.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import Foundation

import Combine

enum networkError:Error{
    
    case invalidUrl
    case noResponce
    case noData
}

class ApiHandler{
    
    static let shared = ApiHandler()
    
    private init(){
        
    }
//    
//    func getSchoolsList(completionHandler:@escaping(Result<[SchoolsListModel],networkError>) -> Void){
//        
//        guard let schoolsUrl = URL.SchoolsUrl() else{
//            
//            return completionHandler(.failure(.invalidUrl))
//        }
//        
//
//        URLSession.shared.dataTask(with: schoolsUrl){ data , responce , error in
//            
//            guard let data = data, error == nil else{
//                
//                return completionHandler(.failure(.noData))
//            }
//            
//            do {
//                let schoolsList =  try JSONDecoder().decode([SchoolsListModel].self,from: data)
//                
//                print(schoolsList)
//                completionHandler(.success(schoolsList))
//            }catch{
//                
//                completionHandler(.failure(.noResponce))
//            }
//        }
//    }
    
    private var bag = Set<AnyCancellable>()
    
    func getSchoolsList(completionHandler:@escaping(Result<[SchoolsListModel],networkError>) -> Void){
        
        guard let schoolsUrl = URL.SchoolsUrl() else{
       
                   return completionHandler(.failure(.invalidUrl))
               }
        
        URLSession.shared.dataTaskPublisher(for:schoolsUrl)
            .receive(on: DispatchQueue.main)
            .map(\.data)
            .decode(type: [SchoolsListModel].self, decoder: JSONDecoder())
            .sink { res in
                
                
            } receiveValue: {  productsdata in
                
                completionHandler(.success(productsdata))
                
                print(productsdata)
            }
            .store(in: &bag)
        
    }
    
}
