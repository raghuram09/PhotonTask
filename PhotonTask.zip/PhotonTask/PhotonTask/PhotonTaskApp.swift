//
//  PhotonTaskApp.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

@main
struct PhotonTaskApp: App {
    var body: some Scene {
        WindowGroup {
            PhotonTaskApp()
        }
    }
}
