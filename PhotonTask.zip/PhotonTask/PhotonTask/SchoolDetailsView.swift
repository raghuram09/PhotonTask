//
//  SchoolDetailsView.swift
//  PhotonTask
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

struct SchoolDetailsView: View {
    
    let schoolDetail:SchoolsListModel

    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

//#Preview {
//    SchoolDetailsView()
//}
